
rcpparma_hello_world <- function(){
	.Call( "rcpparma_hello_world", PACKAGE = "sbfac" )
}

