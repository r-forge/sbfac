updateZ <- function (Z_, Ra_, maxes_, argsorts_, mu_) 
.Call("file1c06dac8", Z_, Ra_, maxes_, argsorts_, mu_, PACKAGE = "sbfac")

