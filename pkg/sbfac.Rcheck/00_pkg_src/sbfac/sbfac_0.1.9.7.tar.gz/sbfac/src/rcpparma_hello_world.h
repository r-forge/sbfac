#ifndef _sbfac_RCPP_HELLO_WORLD_H
#define _sbfac_RCPP_HELLO_WORLD_H

#include <RcppArmadillo.h>

RcppExport SEXP rcpparma_hello_world() ;

#endif
